'use client'
import React from "react";


import Home from "./_components/Home";

export default function page() {
  return (
  
      <Home />
    
  );
}
