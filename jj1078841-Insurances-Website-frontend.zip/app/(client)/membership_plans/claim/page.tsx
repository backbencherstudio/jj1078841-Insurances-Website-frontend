import MyClaim from '@/app/_components/sections/MyClaim'
import React from 'react'

export default function page() {
  return (
    <div>
        <MyClaim/>
    </div>
  )
}
