import PaymentForm from '@/app/_components/sections/PaymentForm'
import React from 'react'

export default function page() {
  return (
     <PaymentForm/>
  )
}
