 import Home from "./_components/Home";

export default function HomePages() {
  return (
    <>
    <Home/>
    </>
  );
}
