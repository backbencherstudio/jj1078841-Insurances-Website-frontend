import React from 'react'

export default function page() {
  return (
    <div className=' min-h-screen container mx-auto'>page</div>
  )
}
