
import React from 'react'
import Dashboard from './_components/Dashboard';



export default function DashboardHome() {
  return (
    <Dashboard />
  );
}
