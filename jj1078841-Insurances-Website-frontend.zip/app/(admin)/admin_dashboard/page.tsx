import React from 'react'
import AdminDashboard from './_components/AdminDashboard';
 
 
 

export default function DashboardHome() {
  return (
   
    <AdminDashboard/>

   
      
    
  );
}
