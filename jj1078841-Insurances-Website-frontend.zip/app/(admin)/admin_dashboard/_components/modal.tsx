import React from 'react'

export default function modal() {
  return (
    <div>modal</div>
  )
}
